package com.sericefeign.sericefeign.hystric;

import com.sericefeign.sericefeign.interfaces.SchedualServiceHi;
import org.springframework.stereotype.Component;

@Component
public class SchedualServiceHiHystric implements SchedualServiceHi {
    @Override
    public String sayHiFromClientOne(String name) {
        return "feign:sorry "+name;
    }
}
